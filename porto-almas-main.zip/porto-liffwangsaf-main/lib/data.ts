import React from "react";
import { CgWorkAlt } from "react-icons/cg";
import { FaReact } from "react-icons/fa";
import { LuGraduationCap } from "react-icons/lu";
import wartafenoImg from "@/public/images/project/wartefeno/p.png";
import siakadImg from "@/public/images/project/siakad/colab.png";
import amikomImg from "@/public/images/project/amikom/ya.png";
import hrtoolsImg from "@/public/images/project/hr-tools/ntah.png";

export const links = [
  {
    name: "Home",
    hash: "#home",
  },
  {
    name: "About",
    hash: "#about",
  },
  {
    name: "My Wife",
    hash: "#projects",
  },
  {
    name: "Skills",
    hash: "#skills",
  },
  {
    name: "Experience",
    hash: "#experience",
  },
  {
    name: "Contact",
    hash: "#contact",
  },
] as const;
export const experiencesData = [
  {
    title: "Web Programmer",
    location: "Central Java, Indonesia",
    description:
      "Learning programs from a website to become useful knowledge for the future",
    icon: React.createElement(CgWorkAlt),
    date: "Jan 2025 - Present",
  },
  {
    title: "Script Developer",
    location: "Central Java, Indonesia",
    description:
      "Create functions and also case type systems and plugins, to create a WhatsApp bot script.",
    icon: React.createElement(CgWorkAlt),
    date: "Jan 2025 - Jan 2025",
  },
  {
    title: "C.ai",
    location: "Central Java, Indonesia",
    description:
      "Create an AI character system to help with daily life, and also be able to chat.",
    icon: React.createElement(CgWorkAlt),
    date: "Nov 2024",
  },
  {
    title: "Java Script",
    location: "Central Java, Indonesia",
    description:
      "I have been studying Java Script (Js) language since 2023.",
    icon: React.createElement(CgWorkAlt),
    date: "Mar 2023",
  },
] as const;
export const projectsData = [
  {
    title: "ELAINA",
    description:
      "Elaina is my wife, He has a nickname Elaina The Ashen Witch. Elaina has beautiful gray hair, a pretty face, a kind nature and a funny personality, she is the perfect woman for me!",
    screenshots: [
      "images/project/cekresi/furina.png",
    ],
    image: "images/project/cekresi/furina.png",
    tech: [
      "/images/icon/javascript.svg",
    ],
    demoUrl: null,
    githubUrl: null,
    features: [
      "Name : Elaina - Ireina.",
      "Date of Birth : October 17", 
      "Characteristic : Nice beautiful woman with white hair", 
      "Series : Wandering Witch: The Journey of Elaina ( Majo No Tabi - Tabi Elaina", 
    ],
    languages: ["Elainaa"],
  },
  {
    title: "Shinomiya Kaguya ",
    description:
      "Kaguya is one of my wives, she has black hair, a beautiful face, a quiet nature but is very cute. She is an elegant and perfect woman!.",
    screenshots: [
      "images/project/ikanme/lexxius.png",
    ],
    image: "images/project/ikanme/lexxius.png",
    tech: [
      "/images/icon/typescript.svg",
    ],
    demoUrl: null,
    githubUrl: null,
    features: [
      "Name : Shinomiya Kaguya",
      "Date of Birth : January 1",
      "Characteristic : Elegant, and very cute", 
      "Series : Kaguya-sama, Love is War", 
    ],
    languages: ["Shinomiya Kaguya"],
  },
  {
    title: "Terakomari",
    description:
      "Gandesblood Komari is a cute woman with yellow hair, has a cute nature, Her adorable behavior makes me love her so much. Komari is a woman I love so much.",
    screenshots: [
      "images/project/mpl/millicent.png",
    ],
    image: "images/project/mpl/millicent.png",
    tech: [
      "/images/icon/bootstrap.svg",
    ],
    demoUrl: null,
    githubUrl: null,
    features: [
      "Name : Terakomari Gandesblood.",
      "Date of birth : February 18th.", 
      "Characteristic : Cute short woman", 
      "Series : Hikikomari Kyuuketsuki no Monmon", 
    ],
    languages: ["Terakomari"],
  },
  {
    title: "Masuzu Natsukawa",
    description:
      "Natsukawa is a beautiful woman, with white hair, has a good nature and likes to joke around, a bit tsundere. She is a beautiful woman and I love her very much.",
    screenshots: [
      "images/project/siakad/colab.png",
    ],
    image: "images/project/siakad/colab.png",
    tech: [
      "/images/icon/codeigniter.svg",
    ],
    demoUrl: null,
    githubUrl: null,
    features: [
      "Name : Masuzu Natsukawa.",
      "Date of Birth: July 26",
      "Characteristic : Beautiful and cute woman", 
      "Series : Ore no Kanojo to Osananajimi ga Shuraba Sugiru", 
    ],
    languages: ["Masuzu Natsukawa"],
  },
] as const;

export const skillsData = [
  "HTML",
  "CSS",
  "JavaScript",
  "TypeScript",
  "Tailwind",
  "Bootstrap",
  "Laravel",
  "Git",
  // "Framer Motion",
] as const;

export const skilss = [
  {
    id: 2,
    imgUrl:
      "https://upload.wikimedia.org/wikipedia/commons/d/d5/Tailwind_CSS_Logo.svg",
  },
  {
    id: 3,
    imgUrl: "/images/icon/bootstrap.svg",
  },
  
  {
    id: 10,
    imgUrl: "/images/icon/javascript.svg",
  },
  // {
  //   id: 10,
  //   imgUrl:
  //     "https://upload.wikimedia.org/wikipedia/commons/9/98/WordPress_blue_logo.svg",
  // },
] as const;
