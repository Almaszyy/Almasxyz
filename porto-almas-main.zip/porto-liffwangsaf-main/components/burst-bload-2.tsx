import React from "react";

export default function BurstBload2() {
  return (
    <div className="top-10">
      <img
        src="/images/icon/burst-bloat-2.svg"
        alt="projects shape Alif Bilal Rozzaqiア"
        className="-z-10 top-0 -right-1 md:w-12 w-6"
        width="24"
        height="24"
      />
    </div>
  );
}
